#ifndef __XLINK_NETWORK_H__
#define __XLINK_NETWORK_H__

//#include "xlink_demo.h"
#include "xlink_All_Device.h"


#define XLINK_DOMAIN  "cm2.xlink.cn"

#define TCP_SENDBUFFER_LEN  2048
//#define OPEN_CLIENT_SSL_ENABLE

#ifdef OPEN_CLIENT_SSL_ENABLE
#define XLINK_SERVER_PORT 	23779
#else
#define XLINK_SERVER_PORT 	23778
#endif

#define TCP_LOCAL_PORT  	5001
#if XLINK_SERVER_PORT == 80
#define XLINK_IS80PORT 1
#else
#define XLINK_IS80PORT 0
#endif

extern void xlink_udp_init(void);
extern void xlink_tcp_init(ip_addr_t *ipaddr_t,int s_port);
extern void xlink_network_init(void);
extern void xlink_func_process(void);
extern void xlink_disconnect_cloud_process(void);
extern void xlink_tcp_send_package(unsigned char *data, unsigned int datalen);
extern void xlink_senduart_to_local(xlink_addr *addr, unsigned char *data,
		unsigned int datalen);

extern int check_is_valid_ip(const char *ip);
#endif


