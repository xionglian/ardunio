#include "c_types.h"
#include "osapi.h"
#include "gpio.h"
#include "ip_addr.h"
#include "espconn.h"
#include "driver/uart.h"
#include "driver/uart_register.h"
#include "../include/driver/xlink_led.h"

#include "xlink_demo.h"
#include "xlink_config.h"
#include "xlink_ringbuf.h"
#include "xlink_network.h"

#ifndef XLINK_FUNC
#define XLINK_FUNC
#endif

//以下两个参数需要在Xlink云平台创建产品以后得到
#define XLINK_PRODUCT_ID   "160fa2b2645d03e9160fa2b2645d6001"//<替换为你自己的产品ID>
#define XLINK_PRODUCT_KEY  "1ecd5505015ac4dff4a4babd5e044efe"//<替换为你自己的产品密钥>

#define MAX_FRAME_LEN           512
#define QUEUE_BUF_LEN           2048
#define xlink_recvTaskQueueLen  10

XLINK_LOCAL_STA    g_AllSta;
XLINK_USER_CONFIG  user_config;

static   unsigned char  tcp_recbuf[2048];

volatile unsigned int TempGLen = 0;
volatile unsigned short tcpsenbuflen = 0;
volatile unsigned char pidkey_w_flag = 0;

volatile unsigned char Isconnectserver = 0;
volatile unsigned char IsSendDataFlag = 0;
volatile int IsSendDataLen = 0;
volatile int IsSendDataMode = 0;

static  unsigned char server_set_dp[SET_DP_MAX_LEN];

extern Kfifo tcpdata_send;
void XLINK_FUNC process_dp_pass_data(void)
{
	extern bool Pswtich;
	if(IsSendDataFlag){
		switch(IsSendDataMode){
			case 2:
				Pswtich = server_set_dp[3];
				GPIO_OUTPUT_SET(GPIO_ID_PIN(LED_POWER_NUM), Pswtich==0?LED_OFF:LED_ON);
				break;
			default:
				break;
		}
		IsSendDataFlag = 0;
	}
}

/**
 * 接收APP发送到设备的数据  -- 公网
 */
void XLINK_FUNC pipe1_call(unsigned char * data, x_uint32 datalen,
		x_uint32 device_id, x_uint8 *opt) {
	//os_printf("recv tcp pipe package len %d  deviceid %d \r\n", datalen,\
			device_id);
}

/**
 * 接收APP发送到设备的数据 -- 公网
 */
static void XLINK_FUNC pipe2_call(unsigned char * data, x_uint32 datalen,
		x_uint8 *opt) {
	//os_printf("recv tcp pipe2 package len %d  \r\n", datalen);
}

/**
 * 接收APP发送到设备的数据--本地
 */
static void XLINK_FUNC udp_pipe_call(unsigned char *data, x_uint32 datalen,
		xlink_addr *addr) {
	//os_printf("recv udp pipe package len %d   %s \r\n", datalen,data);
}

volatile unsigned char connect_server_flag = 0;
static XLINK_FUNC void app_status(XLINK_APP_STATUS status) {
	switch (status) {
		case XLINK_WIFI_STA_APP_CONNECT: /*用户连接*/
			//os_printf("****new app connect****\r\n");
			break;

		case XLINK_WIFI_STA_APP_DISCONNECT:/*用户离开*/
			//os_printf("**** app disconnect****\r\n");
			break;

		case XLINK_WIFI_STA_APP_TIMEOUT:/*通讯超时*/
			//os_printf("**** app timeout****\r\n");
			break;

		case XLINK_WIFI_STA_CONNECT_SERVER:
			//os_printf("**** tcp connect to server success****\r\n");
			break;

		case XLINK_WIFI_STA_DISCONNCT_SERVER:
			os_printf("**** tcp disconnect to server ****\r\n");
			extern void xlink_led_timer_stop(void);
			xlink_led_timer_stop();
			if(g_AllSta.bit.isConnectWIFI)
			{
				xlink_set_led_state(LED_STATE_NUM, LED_ON);
			}
			else
			{
				xlink_set_led_state(LED_STATE_NUM, LED_OFF);
			}
			g_AllSta.bit.isConnectedServer = 0;
			g_AllSta.bit.isNeedSend = 1;

			Kfifo_reset(&tcpdata_send);
			XlinkInitData(); //must reinit before tcp connect or when tcp close
			if(connect_server_flag){
				//xlink_getwifi_status_resp();
			}
			connect_server_flag = 0;
			break;
		case XLINK_WIFI_STA_LOGIN_SUCCESS:	//登录服务器成功
			os_printf("**** tcp login server success****\r\n");
			connect_server_flag = 1;
			g_AllSta.bit.isConnectedServer = 1;
			g_AllSta.bit.isNeedSend = 1;
			g_AllSta.bit.isNeedSendServerSta = 1;
			//xlink_getwifi_status_resp();
			extern void xlink_led_timer(uint32_t time);
			xlink_led_timer(1000);
			break;
		default:
			break;
	}
}

/**
 * UDP 本地发送数据
 */
int XLINK_FUNC send_data_to_local(xlink_addr *addr, unsigned char *data,
		unsigned int datalen) {
#if XLINK_DEBUG_ON
	//os_printf("fun %s  line %d datalen %d\r\n", __FUNCTION__, __LINE__,\
				datalen);
#endif

	xlink_senduart_to_local(addr,data,datalen);
	return datalen;
}

/**
 * TCP 向服务器发送数据
 */
int XLINK_FUNC send_data_to_cloud(unsigned char *data, unsigned int datalen) {
#if XLINK_DEBUG_ON
	//os_printf("fun %s  line %d datalen %d\r\n", __FUNCTION__, __LINE__,\
			datalen);
#endif

	xlink_tcp_send_package(data, datalen);
	return datalen;
}



void XLINK_FUNC upgrade_task(XLINK_UPGRADE *data)
{
     if((data->urlLength == 0) || (data->urlstr == NULL))
        return;
     //os_printf("get urlength=%d\n",data->urlLength);
     //os_printf("get mCheckFlag=%d  md5lenth=%d md5str=%s\n",data->mCheckFlag,data->checkStrLength,data->checkStr);

	 os_printf("the url=%s urllen=%d\r\n",data->urlstr,data->urlLength);
	 xlink_update_as_http(data->urlstr,data->urlLength,"wifixxx",data->checkStr);
}

void XLINK_FUNC time_callback(XLINK_SYS_TIME *time) {
	xlink_printf("xlink updata current time\r\n");
}

XLINK_FUNC static void SetDataPiont(unsigned char *data, int datalen)
{
	xlink_printf("xlink SetDataPiont,len =%d\r\n", datalen);
	if(datalen <= SET_DP_MAX_LEN) {
		memcpy(server_set_dp,data,datalen);
		IsSendDataLen = datalen;
		IsSendDataFlag = 1;
		IsSendDataMode = 2;
	}
}

XLINK_FUNC static void GetAllDataPiont(unsigned char *data, int *datalen)
{
	unsigned char i=0;
	unsigned short j=0;
    int len_dp = 0;

    len_dp = *datalen;
    extern bool Pswtich;

    data[0] = 0;
	data[1] = 0;//BYTE类型
	data[2] = 1;
	data[3] = Pswtich;

    *datalen = 4;
#if DATAPOINT_DEBUG_ON
    xlink_printf(" get datapoint len=%d....\r\n",*datalen);
#endif
}

XLINK_FUNC void xlink_resolve_mcu_cmd(void)
{
//	if(ptppkt.pktlentmp > 7){
//		tcpsenbuflen = ptppkt.pktlentmp + 2;
//		if(tcpsenbuflen > MAX_FRAME_LEN){
//			tcpsenbuflen = MAX_FRAME_LEN;
//		}
//	}
//	else
//	{
//		tcpsenbuflen = 7;
//	}
//
//	memset(Q_Pull_Outbuf, 0, QUEUE_BUF_LEN);
//	TempGLen = Kfifo_Get(&ring_buf_data, Q_Pull_Outbuf, tcpsenbuflen);
//	Kfifo_Add_Out(&ring_buf_data,TempGLen);
//	if(TempGLen == 0){
//		return;
//	}
//	Xlink_PassThroughProtolPutData(&ptppkt,(uint8_t *)Q_Pull_Outbuf, TempGLen);
}

//TCP pipe数据发送回调,handle与发送handle对应，val为0表示失败，1表示成功
void Xlink_tcp_pipe_send_cb(unsigned short handle,unsigned char val)
{
	//xlink_printf("****tcp_pipe_send_cb handle=%d,val=%d****\r\n",handle,val);
}

//TCP pipe2数据发送回调,handle与发送handle对应，val为0表示失败，1表示成功
void Xlink_tcp_pipe2_send_cb(unsigned short handle,unsigned char val)
{
	//xlink_printf("****tcp_pipe2_send_cb handle=%d,val=%d****\r\n",handle,val);
}

//udp pipe数据发送回调,handle与发送handle对应，val为0表示失败，1表示成功
void Xlink_udp_pipe_send_cb(unsigned short handle,unsigned char val)
{
	//xlink_printf("****udp_pipe_send_cb handle=%d,val=%d****\r\n",handle,val);
}

//TCP 数据端点更新发送回调,handle与发送handle对应，val为0表示失败，1表示成功
void Xlink_tcp_datapoint_send_cb(unsigned short handle,unsigned char val)
{
	//xlink_printf("****tcp_datapoint_send_cb handle=%d,val=%d****\r\n",handle,val);
}


XLINK_FUNC int xlink_demo_init(void) {
	char proKey[33]={0};
	char m_pID[33]={0};

	user_config.tcp_pipe2 = NULL;
	user_config.tcp_pipe = pipe1_call;
	user_config.udp_pipe = udp_pipe_call;
	user_config.status = app_status;
	user_config.DebugPrintf = NULL;
	user_config.wifisoftVersion = 4;
	user_config.wifi_type = 1;
	user_config.in_internet = 1;
	user_config.server_time = NULL;
	user_config.upgrade = upgrade_task;

	user_config.mcuHardwareSoftVersion = user_config.wifisoftVersion;
	user_config.mcuHardwareVersion = user_config.wifi_type;

	user_config.send_tcp = send_data_to_cloud;
	user_config.send_udp = send_data_to_local;

	user_config.tcpRecvBuffer = tcp_recbuf;
	user_config.tcpRecvBuuferLength = 2048;

	user_config.Xlink_GetAllDataPoint = GetAllDataPiont;
	user_config.Xlink_SetDataPoint = SetDataPiont;
	user_config.maclen = 6;

	user_config.tcp_datapoint_send_cb = Xlink_tcp_datapoint_send_cb;
	user_config.tcp_pipe2_send_cb = Xlink_tcp_pipe2_send_cb;
	user_config.tcp_pipe_send_cb = Xlink_tcp_pipe_send_cb;
	user_config.udp_pipe_send_cb = Xlink_udp_pipe_send_cb;

	wifi_get_macaddr(0, user_config.mac);
	xlinkConfigInit(&user_config);

	os_printf("start to read pid and key.......\r\n");
	XlinkReadProductIDKEY(&pidkey_w_flag,m_pID, proKey);
	m_pID[32] = '\0';
	proKey[32] = '\0';

	pidkey_w_flag = PIDKEY_WRITE_FLAG;
	memcpy(m_pID, XLINK_PRODUCT_ID, 32);
	memcpy(proKey, XLINK_PRODUCT_KEY, 32);

	if (XlinkSystemInit(m_pID, proKey, &user_config) != 0)
	{
		XlinkGetServerTime();
	}

	if(pidkey_w_flag != PIDKEY_WRITE_FLAG)
		return 0;

	XlinkPorcess_UDP_Enable();

	if(user_config.setServerStatus != NULL){
		user_config.setServerStatus(0, XLINK_IS80PORT);
	}
	return 1;
}


