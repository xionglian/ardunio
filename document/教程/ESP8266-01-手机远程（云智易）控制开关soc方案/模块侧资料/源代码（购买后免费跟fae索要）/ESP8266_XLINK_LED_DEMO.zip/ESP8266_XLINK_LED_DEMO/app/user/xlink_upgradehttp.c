#include "c_types.h"
#include "upgrade.h"

//#include "../xlinksrc/xlink_All_Device.h"
#include "xlink_All_Device.h"

#include "xlink_upgradehttp.h"
#include "xlink_network.h"


#define REMOTE_HOST_URL  "static.xlink.cn"

#define pheadbuffer "Connection: keep-alive\r\n\
Cache-Control: no-cache\r\n\
User-Agent: Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36 \r\n\
Accept: */*\r\n\
Accept-Encoding: gzip,deflate\r\n\
Accept-Language: zh-CN,eb-US;q=0.8\r\n\r\n"


static os_timer_t at_delay_check;

static struct espconn    http_client_conn;
static ip_addr_t         http_down_ip;
//static os_timer_t      http_dns_timer;

struct upgrade_server_info *xlinkServer = NULL;
server_push_upgrade_info_t  xlink_server_info;
xlink_down_file_info        UpGrade_info_t;

int  HTTP_GetPath(char *url, char *path);
int  HTTP_Get_IP_PORT(char *url, char *ip, char *port);
int  httpConnectHostInit(server_push_upgrade_info_t *server_info);
int  IPStringtoAddr(const char *ip,unsigned int *ret_addr);
void httpGetHostByName(const char *hostName);

extern int check_is_valid_ip(const char *ip);

LOCAL void ICACHE_FLASH_ATTR
update_rsp(void *arg)
{
	struct upgrade_server_info *server = arg;

	if(server->upgrade_flag == true){
	   os_printf("device OTA upgrade success\r\n");
	   system_upgrade_reboot();
	}else{
	   os_printf("device OTA upgrade failed\r\n");
	}

	os_free(server->url);
	server->url = NULL;
	os_free(server);
	server = NULL;
}

LOCAL void ICACHE_FLASH_ATTR
upgrade_wait(void *arg)
{
	struct espconn *pespconn = arg;
	os_timer_disarm(&at_delay_check);
	if(pespconn != NULL){
		os_printf("espconn_disconnect call....\r\n");
		espconn_disconnect(pespconn);
	}else{
	}
}



void XLINK_FUNC update_recv(void *arg, char *pdata, unsigned short len)
{
	struct espconn *pespconn = (struct espconn *)arg;

	if (xlinkServer != NULL){
	   os_free(xlinkServer);
	   xlinkServer = NULL;
	}

	os_timer_disarm(&at_delay_check);
	os_printf("malloc memory for upgrade_server_info...\r\n");

	xlinkServer = (struct upgrade_server_info *)os_zalloc(sizeof(struct upgrade_server_info));

	if(xlinkServer == NULL){
		os_printf("Can't not malloc memory for upgrade_server_info...\r\n");
		os_free(xlinkServer);
		xlinkServer = NULL;
		return ;
	}

	xlinkServer->upgrade_version[5] = '\0';
	xlinkServer->pespconn = pespconn;

	os_memcpy(xlinkServer->ip, pespconn->proto.tcp->remote_ip, 4);

	xlinkServer->port = xlink_server_info.port; //get port from url
	xlinkServer->check_cb = update_rsp;
	xlinkServer->check_times = 60000;


	if(xlinkServer->url == NULL ){
	   os_printf("malloc memory for upserver->url.......\r\n" );
	   xlinkServer->url = (uint8 *)os_zalloc(1024);
	}
	if(xlinkServer->url == NULL){
	   os_printf("malloc memory upserver->url failed.......\r\n" );
	   os_free(xlinkServer->url);
	   return;
	}else{
		os_printf("malloc memory upserver->url successfully.......\r\n" );
	}

	os_printf("[OTA]Server port=%d Path=%s\r\n", xlinkServer->port, xlink_server_info.path);

	if (system_upgrade_userbin_check() == UPGRADE_FW_BIN1) {
	   //os_memcpy(user_bin, "user2.4096.new.6.bin", 32);
	   os_printf("download user2 bin------\r\n");
	} else if (system_upgrade_userbin_check() == UPGRADE_FW_BIN2) {
	   //os_memcpy(user_bin, "user1.4096.new.6.bin", 32);
	   os_printf("download user1 bin------\r\n");
	}
    //os_printf("the last xlink_server_info.path=%s\r\n",xlink_server_info.path);

#if 0  //pc test or for xlink cloud
       os_sprintf(upserver->url,
            "GET /%s HTTP/1.1\r\nHost: "IPSTR"\r\n"pheadbuffer"",
   		 xlink_server_info.path, IP2STR(upserver->ip));
#endif

#if 1// for xlink cloud
	os_sprintf(xlinkServer->url,
		    "GET /%s HTTP/1.1\r\nHost: %s\r\n"pheadbuffer"",
	         xlink_server_info.path,xlink_server_info.ipaddr);
#endif

   os_printf("--the last url format is=%s\r\n",xlinkServer->url);
}


void XLINK_FUNC update_send_cb(void *arg)
{
	struct espconn *pespconn = arg;
	os_timer_disarm(&at_delay_check);
	os_timer_setfn(&at_delay_check, (os_timer_func_t *)upgrade_wait, pespconn);
	os_timer_arm(&at_delay_check, 10000, 0);
	os_printf("update_sent_cb\r\n");
}

void XLINK_FUNC update_discon_cb(void *arg)
{
	struct espconn *pespconn = (struct espconn *)arg;

	os_printf("update_discon_cb callback......\r\n");

	if(pespconn->proto.tcp != NULL){
		os_free(pespconn->proto.tcp);
	}
	if(pespconn != NULL){
		os_free(pespconn);
	}
	if(system_upgrade_start(xlinkServer) == false){
		os_printf("upgrade error.......\r\n");
	}
	else{
		os_printf("upgrade ing.......\r\n");
	}
}

void XLINK_FUNC update_recon_cb(struct espconn* pConn,sint8 err) {

	struct espconn *pespconn = (struct espconn *)pConn;

	os_printf("update_recon_cb callback.....\r\n");

	if(pespconn->proto.tcp != NULL){
	   os_free(pespconn->proto.tcp);
	}
	os_free(pespconn);
	if(xlinkServer != NULL){
	   os_free(xlinkServer);
	   xlinkServer= NULL;
	}
}



void XLINK_FUNC update_connect_cb(void *arg)
{
	struct espconn *pespconn = (struct espconn*)arg;
	char ret = 0;
    char *temp_buf = NULL;

	os_printf("fun %s line %d connect server start\r\n", __FUNCTION__,__LINE__);

	espconn_regist_disconcb(pespconn,update_discon_cb);
	espconn_regist_recvcb(pespconn, update_recv);
	espconn_regist_sentcb(pespconn, update_send_cb);

	temp_buf = (char *)os_zalloc(1024);

#if 0 //for pc ota test
	os_sprintf(temp_buf,"GET /v1/device/rom/?is_format_simple=true HTTP/1.0\r\nHost: "IPSTR"\r\n"pheadbuffer"",
	             IP2STR(pConn->proto.tcp->remote_ip));
#endif
    os_printf("the download bin xlink_server_info.path=%s\r\n",xlink_server_info.path);

#if 1  //for xlink cloud ota test
	os_sprintf(temp_buf,"GET HTTP/1.1\r\nHost: %s\r\n"pheadbuffer"",
			 xlink_server_info.ipaddr);
#endif

	os_printf("the download bin xlink_server_info.ipaddr=%s\r\n",xlink_server_info.ipaddr);
	os_printf("the http requst bin info=%s\r\n",temp_buf);
	os_printf("the http requst bin len=%d\r\n",os_strlen(temp_buf));

	ret = espconn_send(pespconn,temp_buf,os_strlen(temp_buf));
	if (ret != 0) {
		os_printf("send get download file request failed\r\n");
	}else{
		os_printf("send get download file request success\r\n");
	}
	os_free(temp_buf);
	temp_buf = NULL;
}

void XLINK_FUNC httpTcpClentNetInit(unsigned char *ipaddr)
{
    if(http_client_conn.proto.tcp == NULL){
    	http_client_conn.proto.tcp = (esp_tcp*)os_zalloc(sizeof(esp_tcp));
    }

	int tcp_local_port = 0;

	os_memcpy(&http_client_conn.proto.tcp->remote_ip,ipaddr,4);

	os_printf("http_tcp_client ip=%d.%d.%d.%d\r\n",
			http_client_conn.proto.tcp->remote_ip[0], http_client_conn.proto.tcp->remote_ip[1],
			http_client_conn.proto.tcp->remote_ip[2],http_client_conn.proto.tcp->remote_ip[3]);

	http_client_conn.type = ESPCONN_TCP;
	http_client_conn.state = ESPCONN_NONE;

	tcp_local_port = espconn_port();
	if(tcp_local_port == 5001){
		tcp_local_port += 5;
	}

	http_client_conn.proto.tcp->local_port = tcp_local_port;
	http_client_conn.proto.tcp->remote_port = xlink_server_info.port; //remote port

	espconn_regist_connectcb(&http_client_conn,
			(espconn_connect_callback) update_connect_cb);
	espconn_regist_reconcb(&http_client_conn,
			(espconn_reconnect_callback) update_recon_cb);
	espconn_connect(&http_client_conn);

}


void XLINK_FUNC httpDnsFound(const char* name,ip_addr_t *ipaddr,void *arg)
{
	struct espconn *pespconn = (struct espconn *) arg;
    unsigned char ip_addr[4];

	if (ipaddr == NULL) {
		os_printf("http_dns_found NULL\r\n");
		return;
	}

	os_memset(ip_addr,0,sizeof(ip_addr));

	os_printf("http down file ip is=%d.%d.%d.%d\n",
			*((uint8 * )&ipaddr->addr), *((uint8 * )&ipaddr->addr + 1),
			*((uint8 * )&ipaddr->addr + 2), *((uint8 * )&ipaddr->addr + 3));

	if (http_down_ip.addr == 0 && ipaddr->addr != 0) {

			http_down_ip.addr = ipaddr->addr;
			os_memcpy(ip_addr,&ipaddr->addr, 4);
			os_printf("have get the http down ip\r\n");

			//if(http_down_ip.addr == 0)return;
			//os_timer_disarm(&http_dns_timer);
			httpTcpClentNetInit(ip_addr); //http tcp client init
     }
}

/*
 @check if have resolved dns
 @1s call a time
 * */
//void XLINK_FUNC httpDnsCheckCallback(void *arg) {
//
//	struct espconn *pespconn = arg;
//	os_printf("http_dns_check_cb\n");
//	espconn_gethostbyname(pespconn, xlink_server_info.ipaddr, &http_down_ip,httpDnsFound);
//	os_timer_arm(&http_dns_timer, 1000, 0);
//}

void XLINK_FUNC httpStartDns(struct espconn *pespconn,const char *hostname) {

	http_down_ip.addr = 0;

	espconn_gethostbyname(pespconn, hostname, &http_down_ip,httpDnsFound);

//	os_timer_disarm(&http_dns_timer);
//	os_timer_setfn(&http_dns_timer,(os_timer_func_t *) httpDnsCheckCallback, pespconn);
//	os_timer_arm(&http_dns_timer, 1000, 0);
}



int XLINK_FUNC xlinkHttpStartDownFile(xlink_down_file_info *UpDateParam) {

	char error = 0;
	char portBuf[8];
	char tempBuf[256];

	memset(portBuf, 0, sizeof(portBuf));
	memset(&xlink_server_info, 0, sizeof(xlink_server_info));

	memset(tempBuf, 0, 256);
	memcpy(tempBuf, UpDateParam->m_url, UpDateParam->m_urlLength);

	error = HTTP_GetPath(tempBuf, xlink_server_info.path); //get the path
	if (error < 0){
		os_printf("\r\n......get url path error.....\r\n");
		return 0;
	}

	os_printf("resolve the url path=%s\r\n",xlink_server_info.path);

	memset(tempBuf, 0, 256);
	memcpy(tempBuf, UpDateParam->m_url, UpDateParam->m_urlLength);

	error = HTTP_Get_IP_PORT(tempBuf, xlink_server_info.ipaddr, portBuf); //get domain and port
	if (error < 0){
		os_printf("\r\n......get url ip addr and port error.....\r\n");
		return 0;
	}

	xlink_server_info.port = atoi(portBuf);
	os_printf("resolve the url ip=%s  port=%d\r\n", xlink_server_info.ipaddr, xlink_server_info.port);

	httpConnectHostInit(&xlink_server_info);
	return 0;
}

int XLINK_FUNC HTTP_GetPath(char *url, char *path) {

	char *p;
	p = strstr(url, "http://");
	if (p == NULL) {
		p = strchr(url, '/');
		if (p == NULL){
			return -1;
		}else {
			os_strcpy(path, p+1);  //not include the '/'
			return 0;
		}
	} else {
		p = strchr(url + strlen("http://"), '/');
		if (p == NULL){
			return -1;
		}else {
			os_strcpy(path, p+1);//not include the '/'
			return 0;
		}
	}
}


/*
 *
 @url get from the server
 @ip is a real ip or a domain
 *
 */
 int XLINK_FUNC HTTP_Get_IP_PORT(char *url, char *ip, char *port) {
	char *p = NULL;
	int offset = 0;
	char DOMAIN_NAME[128];
	p = strstr(url, "http://");
	if (p == NULL) {
		offset = 0;
	} else {
		offset = os_strlen("http://");
	}
	p = strchr(url + offset, '/');
	if (p == NULL) {
#ifdef DEBUG_HTTP
		os_printf("url:%s format error\n", url);
#endif
		return -1;
	} else {
		memset(DOMAIN_NAME, 0, sizeof(DOMAIN_NAME));
		memcpy(DOMAIN_NAME, url + offset, (p - url - offset));
		p = strchr(DOMAIN_NAME, ':');
		if (p == NULL) {
			os_strcpy(ip, DOMAIN_NAME);
			os_strcpy(port, "80");
#ifdef DEBUG_HTTP
			os_printf("ip=%s,port=%s\n",ip,port); //debug info
#endif
			return 1;
		} else {
			*p = '\0';
			os_strcpy(ip, DOMAIN_NAME);
			os_strcpy(port, p + 1);
#ifdef DEBUG_HTTP
			os_printf("ip=%s,port=%s\n",ip,port); //debug info
#endif
			return 2;
		}
		return 0;
	}
}

void XLINK_FUNC httpGetHostByName(const char *hostName) {

 	httpStartDns(&http_client_conn,hostName);
 }


int XLINK_FUNC httpConnectHostInit(server_push_upgrade_info_t *server_info) {

	unsigned int Combin_ip = 0;
	unsigned char ipaddr[4];
	int result = -1;

	if(check_is_valid_ip(server_info->ipaddr) != 1) {
		//if the server is domain mode
		//os_printf("is domain format\r\n");
		httpGetHostByName(server_info->ipaddr);
	} else {
		//if the server is ip mode
	    //os_printf("the ipstr=%s,len=%d\r\n",server_info->ipaddr,strlen(server_info->ipaddr));

		result = IPStringtoAddr(server_info->ipaddr,&Combin_ip);
		if(result == SUCCESS){
		    os_printf("change ipstring to int successfully\r\n");
		}else{
		    os_printf("error=%s\r\n",result);
		    return 0;
		}
		if(Combin_ip == 0){
		    os_printf("ipaddr is invalid\r\n");
		    return 0;
		}

        os_memset(ipaddr,0,sizeof(ipaddr));
        ipaddr[0] = (uint8_t)((Combin_ip & 0xFF000000)>>24);
        ipaddr[1] = (uint8_t)(Combin_ip & 0x00FF0000)>>16;
        ipaddr[2] = (uint8_t)(Combin_ip & 0x0000FF00)>>8;
        ipaddr[3] = (uint8_t)(Combin_ip & 0x000000FF);

//		ipaddr[0] = 192;
//		ipaddr[1] = 168;
//		ipaddr[2] = 1;
//		ipaddr[3] = 107;
		httpTcpClentNetInit(ipaddr);
	}
}


int XLINK_FUNC IPStringtoAddr(const char *ip,unsigned int *ret_addr){

	  if(ip == NULL){
		  return NULL_POINTER;
	  }
	  unsigned short digit = 0;
	  unsigned char dotNum = 0;

	  //os_printf("the need resolve ipstar=%s\r\n",ip);
	  while(*ip != '\0'){
		 if((*ip >='0') && (*ip <='9')){
			//++digitNum;
			digit = 10 * digit + (*ip - '0');
			//os_printf("the digit1 value=%d\r\n",digit);
		 }else if(*ip == '.'){
			dotNum++;
			if(dotNum > 3){
				//os_printf("INVALID_dot num ip \r\n");
				return INVALID_FORM;
			}
			if(digit > 255 || digit < 0){
			    //os_printf("num is large than 255\r\n");
			    return OVER_BOUNDARY;
			}
			*ret_addr = (*ret_addr << 8)|digit;
			//os_printf("the ipaddr value1=%ld\r\n",*ret_addr);
			digit = 0;
		 }else{
			 //os_printf("INVALID ip char\r\n");
			 return INVALID_CHAR;
		 }
		 ip++;
	}
	if(dotNum == 3){
		*ret_addr = (*ret_addr << 8)|digit;
		//os_printf("the ipaddr value3=%lu\r\n",*ret_addr);
		return SUCCESS;
	}else{
		//os_printf("INVALID ip form1 \r\n");
		return INVALID_FORM;
	}
}


void XLINK_FUNC xlink_update_as_http(char *url,unsigned int urllen,char *type,char *checkstr)
{
	int rlength = 0;

	os_memset(&UpGrade_info_t,0,sizeof(UpGrade_info_t));
	rlength = sizeof(UpGrade_info_t.m_url);
	if(urllen > rlength){
		os_printf("the url is too long----\r\n");
		return;
	}

    UpGrade_info_t.m_urlLength = urllen;
    os_memcpy(UpGrade_info_t.m_url,url,urllen);
    xlinkHttpStartDownFile(&UpGrade_info_t);
}


