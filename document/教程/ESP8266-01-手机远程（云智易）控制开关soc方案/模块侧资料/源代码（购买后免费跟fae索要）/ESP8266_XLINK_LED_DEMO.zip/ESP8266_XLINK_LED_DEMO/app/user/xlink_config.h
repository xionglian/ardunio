#ifndef _CONFIG_H_
#define _CONFIG_H_

#include "xlink_demo.h"

#define ESP8266_FLASH_SECTOR_SIZE   4096

/*need  to define for the User Data section*/
#define PRIV_PARAM_START_SECTOR     0x7C  //need to change when compile in STEP4


extern void xlinkConfigInit(XLINK_USER_CONFIG *config);
extern int  XlinkWriteProductIDKEY(unsigned char *vflag,char *proid, char *proKey);

#endif /*end of define config.h*/
