#include "ets_sys.h"
#include "osapi.h"
#include "os_type.h"
#include "gpio.h"
#include "user_interface.h"
#include "../include/driver/xlink_led.h"

#ifndef XLINK_FUNC
#define XLINK_FUNC ICACHE_FLASH_ATTR
#endif

bool Pswtich = 0;

void XLINK_FUNC xlink_led_func_init(void)
{
	//led blink PIN
	PIN_FUNC_SELECT(LED_STATE_NAME, LED_STATE_FUNC);
	PIN_FUNC_SELECT(LED_POWER_NAME, LED_POWER_FUNC);

	PIN_PULLUP_EN(LED_STATE_NAME);
	GPIO_OUTPUT_SET(GPIO_ID_PIN(LED_STATE_NUM), LED_OFF);

	PIN_PULLUP_EN(LED_POWER_NAME);
	GPIO_OUTPUT_SET(GPIO_ID_PIN(LED_POWER_NUM), LED_OFF);
}

void XLINK_FUNC xlink_set_led_state(uint32 pin_num,bool status)
{
	GPIO_OUTPUT_SET(pin_num, status);
}
