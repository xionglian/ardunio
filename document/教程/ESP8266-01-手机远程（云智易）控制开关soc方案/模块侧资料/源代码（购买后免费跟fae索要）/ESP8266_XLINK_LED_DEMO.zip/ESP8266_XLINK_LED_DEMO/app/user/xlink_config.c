
#include "xlink_config.h"
//#include "../xlinksrc/xlink_data.h"
//#include "../xlinksrc/xsdk_config.h"

#include "xlink_data.h"
#include "xsdk_config.h"
#include "xlink_All_Device.h"

static int XLINK_FUNC XlinkConfigWriteConfig(char *data,unsigned int datalen);
static int XLINK_FUNC XlinkConfigReadConfig(char *Buffer,unsigned int bufferlen);


#define XLINK_USR_BIN_ADDR_CFG 0 //length is: XLINK_CONFIG_BUFFER_SIZE__
#define XLINK_USR_BIN_ADDR_PDID  XLINK_CONFIG_BUFFER_SIZE__  //length is 180

typedef struct config_info{
	uint8_t auth_pwd_name_buf[XLINK_CONFIG_BUFFER_SIZE__];
    uint8_t product_key_id[66];
}xlink_para_info_t;

xlink_para_info_t xlink_config_parameter;

void XLINK_FUNC xlinkConfigInit(XLINK_USER_CONFIG *config) {

	xlink_memset(&xlink_config_parameter, '\0', sizeof(xlink_config_parameter));
	//system_param_load(PRIV_PARAM_START_SECTOR, 0, &xlink_config_parameter, sizeof(xlink_config_parameter));
    spi_flash_read(PRIV_PARAM_START_SECTOR*4096, (uint32 *)&xlink_config_parameter,sizeof(xlink_config_parameter));
	config->readConfig =  XlinkConfigReadConfig;
	config->writeConfig = XlinkConfigWriteConfig;
}

static int XLINK_FUNC XlinkConfigWriteConfig(char *data,unsigned int datalen) {

	xlink_memcpy(xlink_config_parameter.auth_pwd_name_buf, data, datalen);
	//system_param_save_with_protect(PRIV_PARAM_START_SECTOR, &xlink_config_parameter, sizeof(xlink_config_parameter));
	spi_flash_erase_sector(PRIV_PARAM_START_SECTOR);
	spi_flash_write(PRIV_PARAM_START_SECTOR*4096, (uint32 *)&xlink_config_parameter,sizeof(xlink_config_parameter));
	return datalen;
}


static int XLINK_FUNC XlinkConfigReadConfig(char *Buffer,unsigned int bufferlen) {

	//system_param_load(PRIV_PARAM_START_SECTOR, 0, &xlink_config_parameter, sizeof(xlink_config_parameter));
	spi_flash_read(PRIV_PARAM_START_SECTOR*4096, (uint32 *)&xlink_config_parameter,sizeof(xlink_config_parameter));
	os_memcpy(Buffer,xlink_config_parameter.auth_pwd_name_buf,bufferlen);
	return bufferlen;
}

int XLINK_FUNC XlinkWriteProductIDKEY(unsigned char *vflag,char *proid, char *proKey) {

	memset(xlink_config_parameter.product_key_id,0,65);

	xlink_config_parameter.product_key_id[0] = *vflag;
	memcpy(xlink_config_parameter.product_key_id+1, proid, 32);
	memcpy(xlink_config_parameter.product_key_id + 33, proKey, 32);

	spi_flash_erase_sector(PRIV_PARAM_START_SECTOR);
	spi_flash_write(PRIV_PARAM_START_SECTOR*4096, (uint32 *)&xlink_config_parameter,sizeof(xlink_config_parameter));
	return 0;
}



int XLINK_FUNC XlinkReadProductIDKEY(unsigned char *vflag,char *proid, char *proKey) {
	spi_flash_read(PRIV_PARAM_START_SECTOR*4096, (uint32 *)&xlink_config_parameter,sizeof(xlink_config_parameter));

	*vflag = xlink_config_parameter.product_key_id[0];
	memcpy(proid, xlink_config_parameter.product_key_id + 1,32);
	memcpy(proKey, xlink_config_parameter.product_key_id + 33, 32);
	return 0;
}


