#include "c_types.h"
#include "osapi.h"
#include "ip_addr.h"
#include "espconn.h"
#include "../smartlink/xlink_smartconfig.h"

#include "xlink_data.h"
#include "xlink_All_Device.h"
#include "xlink_network.h"
#include "xlink_ringbuf.h"

static   struct espconn   user_conn;
static   struct _esp_tcp  user_tcp;
struct   espconn   xlink_tcp_net_client;
struct   espconn   xlink_udp_net_server;

volatile unsigned  char send_data_ack = 0;
volatile unsigned  char tcp_connect_flag = 0;
volatile unsigned  int lastConnectServerTime = 0;
volatile unsigned  int time_send_count = 0;

Kfifo    tcpdata_send;
static   unsigned char XLINK_TCP_FIFO[TCP_SENDBUFFER_LEN];

ip_addr_t   raddr;
ip_addr_t   *addrptr = &raddr;
ip_addr_t 	esp_server_ip;

os_timer_t  net_process_timer,dns_resolve_timer;
bool        dns_resolve_done_flag = false;

static unsigned char try_reconnect_num = 0;

void XLINK_FUNC xlink_network_check_ip(void* param);
void XLINK_FUNC xlink_func_process(void);

int XLINK_FUNC check_is_valid_ip(const char *ip) {
	int ret = -1;
	unsigned char dotnum = 0;
	unsigned short maxval = 0;

	while(*ip != '\0'){

		if((*ip >= '0') && (*ip <= '9')){
			  maxval = maxval*10 + (*ip - '0');
		}else if(*ip == '.'){
			 dotnum++;
			 if(dotnum > 3){
		        //os_printf("dot num is large than 3\r\n");
		        return -1;
			 }
			 if(maxval< 0 || maxval >255){
				 //os_printf("max value is larger than 255 value=%d\r\n",maxval);
		        return -1;
			 }
			 maxval = 0;
		}else{
			//os_printf("ipstring char is illegal \r\n");
			  return -1;
		}
		ip++;
	}
	if(maxval >=0 && maxval <=255){
		if(dotnum == 3){
			return 1;
		}
	}
	return -1;
}

int XLINK_FUNC hf_ip2int(char *pStr, ip_addr_t *ipaddr)
{
	const char delimiters[] = ".";
	char cp[16]={0};
	char *pIp1=0, *pIp2=0, *pIp3=0, *pIp4=0;

	strcpy (cp, pStr);
	pIp1 = strtok (cp, delimiters);
	pIp2 = strtok (NULL, delimiters);
	pIp3 = strtok (NULL, delimiters);
	pIp4 = strtok (NULL, delimiters);
	if (pIp1==0 || pIp2==0 || pIp3==0 || pIp4==0)
		return -1;

	ipaddr->addr = atoi(pIp1)|((atoi(pIp2)&0x00ff)<<8)|((atoi(pIp3) & 0x0000ff)<<16)|((atoi(pIp4)&0x000000ff)<<24);

#if XLINK_DEBUG_ON
	os_printf("parse ip adder=%d.%d.%d.%d.......\r\n",(ipaddr->addr & 0xff),((ipaddr->addr & 0xff00)>>8),
			((ipaddr->addr & 0xff0000)>>16),((ipaddr->addr & 0xff000000)>>24));
#endif
	return 1;
}

XLINK_FUNC void xlink_tcp_send_package(unsigned char *data, unsigned int datalen) {
	unsigned int freespace = 0;
    unsigned int DataSize = 0;

	if(datalen == 0 || data == NULL)return;

	DataSize = Kfifo_canread_len(&tcpdata_send);
	freespace = TCP_SENDBUFFER_LEN - DataSize;

#if FIFO_DEBUG_ON
	xlink_printf("---->>>tcp fifo canread datalen=%d freespace=%d <<<<<----\r\n",DataSize,freespace);
#endif

    if(datalen  > freespace){
#if FIFO_DEBUG_ON
    	xlink_printf("---->>>tcp fifo have not enouch memory------\r\n");
#endif
        return ;
    }else{
    	Kfifo_Put(&tcpdata_send, data, datalen);            //push data
    }
}

int XLINK_FUNC get_tcpsend_frame(Kfifo *fifo_type,unsigned char *buffer,unsigned int length){

	unsigned int ret = 0;
	unsigned int data_size  = 0;

	data_size = Kfifo_canread_len(fifo_type);

	if(data_size == 0){
		 //Kfifo_reset(fifo_type);
		 return 0;
	}
#if FIFO_DEBUG_ON
	xlink_printf("---->>>>>>>>>>>>tcp fifo data len=%d------<<<<<<----\r\n",data_size);
#endif

	ret = Kfifo_Get(fifo_type, buffer, length);  //return read length
	Kfifo_Add_Out(fifo_type,ret);

	return ret ;
}



static unsigned char send_buffer[1460]={0};
void XLINK_FUNC send_tcpdata_loop(void)
{
    unsigned int data_len = 0;
//  int i = 0;

	if (send_data_ack != 0) {
		return;
	}
	memset(send_buffer,0,sizeof(send_buffer));
	data_len = get_tcpsend_frame(&tcpdata_send,send_buffer,1460);
	if(data_len == 0){
	   return;
	}

#if FIFO_DEBUG_ON
	xlink_printf("start to send tcp data to cloud---datalen=%ld---->>>\r\n",data_len);
#endif

#ifdef OPEN_CLIENT_SSL_ENABLE
	espconn_secure_sent(&xlink_tcp_net_client, send_buffer, data_len);
#else
	espconn_sent(&xlink_tcp_net_client, send_buffer, data_len);
#endif

	send_data_ack = 1;
	time_send_count = 0;
}


static void XLINK_FUNC xlink_udp_recv_cb(void *arg, char *pdata, unsigned short len) {

	if (pdata == NULL || len == 0) {
		return;
	}

	xlink_addr addr;
	ip_address_t ip_temp_buf;
	ip_temp_buf.ip = 0;

	remot_info *premot = NULL;

	if(espconn_get_connection_info(&xlink_udp_net_server, &premot, 0) != ESPCONN_OK){
		os_printf("get connection info error\r\n");
		return;
    }
	os_memcpy(xlink_udp_net_server.proto.udp->remote_ip, premot->remote_ip, 4);
	xlink_udp_net_server.proto.udp->remote_port = premot->remote_port;

	ip_temp_buf.bit.byte0 = xlink_udp_net_server.proto.udp->remote_ip[0];
	ip_temp_buf.bit.byte1 = xlink_udp_net_server.proto.udp->remote_ip[1];
	ip_temp_buf.bit.byte2 = xlink_udp_net_server.proto.udp->remote_ip[2];
	ip_temp_buf.bit.byte3 = xlink_udp_net_server.proto.udp->remote_ip[3];

	xlink_memset(&addr, 0, sizeof(xlink_addr));
	addr.sin_addr.s_addr = ip_temp_buf.ip;
	addr.sin_port = xlink_udp_net_server.proto.udp->remote_port;
	user_config.process_udp_data((unsigned char *) pdata, len, &addr);
}

void xlink_senduart_to_local(xlink_addr *addr, unsigned char *data,
		unsigned int datalen)
{
	ip_address_t ip_addr;
	ip_addr.ip = addr->sin_addr.s_addr;

	xlink_udp_net_server.proto.udp->remote_port = addr->sin_port;
	xlink_udp_net_server.proto.udp->remote_ip[0] = ip_addr.bit.byte0;
	xlink_udp_net_server.proto.udp->remote_ip[1] = ip_addr.bit.byte1;
	xlink_udp_net_server.proto.udp->remote_ip[2] = ip_addr.bit.byte2;
	xlink_udp_net_server.proto.udp->remote_ip[3] = ip_addr.bit.byte3;
	espconn_sent(&xlink_udp_net_server, data, datalen);
}

void XLINK_FUNC xlink_udp_init(void) {
	esp_udp* udp_addr_info = NULL;

	xlink_udp_net_server.type = ESPCONN_UDP;
	xlink_udp_net_server.state = ESPCONN_NONE;
	xlink_udp_net_server.proto.udp = (esp_udp*) os_zalloc(sizeof(esp_udp));
	xlink_udp_net_server.reverse = NULL;

	udp_addr_info = xlink_udp_net_server.proto.udp;

	udp_addr_info->local_port = 5987;
	udp_addr_info->remote_port = 6000;

	udp_addr_info->remote_ip[0] = 0x00;
	udp_addr_info->remote_ip[1] = 0x00;
	udp_addr_info->remote_ip[2] = 0x00;
	udp_addr_info->remote_ip[3] = 0x00;

	espconn_regist_recvcb(&xlink_udp_net_server,
			(espconn_recv_callback) xlink_udp_recv_cb);
	espconn_create(&xlink_udp_net_server);
}

static void XLINK_FUNC user_xlink_platform_reconnect(struct espconn *pespconn)
{
#if XLINK_DEBUG_ON
    os_printf("user_xlink_platform_reconnect\n");
#endif
	xlink_network_check_ip(NULL);
}


static void XLINK_FUNC xlink_tcp_client_reconnect_cb(struct espconn* pConn) {

#if XLINK_DEBUG_ON
	os_printf("tcp try to reconnect callback......\r\n");
#endif
    user_xlink_platform_reconnect(pConn);
}


static void XLINK_FUNC xlink_tcp_disconnect_cb(void *arg)
{
	struct espconn *pespconn = arg;

    if(pespconn == NULL) {
        return;
    }

#if XLINK_DEBUG_ON
	//os_printf("tcp disconnect callback......\r\n");
#endif
    if(user_config.setServerStatus != NULL){
    	user_config.setServerStatus(0, XLINK_IS80PORT);
    }
	g_AllSta.bit.isTcpReconnect = 0;
	g_AllSta.bit.isConnectedServer = 0;
	xsdk_closeTCP(1);
	Kfifo_reset(&tcpdata_send);
	XlinkInitData(); //must reinit before tcp connect or when tcp close
	xlink_tcp_client_reconnect_cb(pespconn);
}

static void XLINK_FUNC xlink_tcp_recv_cb(struct espconn *pConn, char *pdata, unsigned short len) {
#if XLINK_DEBUG_ON
	//os_printf("get package data include xlink  datalen=%d.......\r\n",len);
#endif
	//user_config.process_tcp_data((unsigned char *) pdata, len, 0);
	XlinkPushData((unsigned char *)pdata,len);
}

static void XLINK_FUNC xlink_tcp_sent_cb(void *arg)
{
#if XLINK_DEBUG_ON
	//os_printf("tcp data have send cb.......\r\n");
#endif
	struct espconn *pespconn = arg;
	send_data_ack = 0; //data have been send out
	time_send_count = 0;
}

static void XLINK_FUNC xlink_tcp_client_connect_cb(struct espconn* pConn) {
#if XLINK_DEBUG_ON
	//os_printf("fun %s line %d connect server start\r\n", __FUNCTION__,__LINE__);
#endif
    if(user_config.setServerStatus != NULL)
    {
	   user_config.setServerStatus(1, XLINK_IS80PORT);
    }
	espconn_regist_recvcb(pConn, (espconn_recv_callback) xlink_tcp_recv_cb);
	espconn_regist_sentcb(pConn, xlink_tcp_sent_cb);
	tcp_connect_flag = 1;
	try_reconnect_num = 0;
}

static void XLINK_FUNC xlink_platform_dns_found(const char *name, ip_addr_t *ipaddr, void *arg) {

	struct espconn *pespconn = (struct espconn *) arg;

	if (ipaddr == NULL) {
		os_printf("user_platform_dns_found NULL\r\n");
		if (wifi_get_opmode() != STATION_MODE) {
			os_printf("wifi_get_opmode=%d\r\n",wifi_get_opmode());
			wifi_set_opmode(STATION_MODE);
		}
		return;
	}
	os_printf("our_platform_dns_found %d.%d.%d.%d\n",
			*((uint8 * )&ipaddr->addr), *((uint8 * )&ipaddr->addr + 1),
			*((uint8 * )&ipaddr->addr + 2), *((uint8 * )&ipaddr->addr + 3));


	if (esp_server_ip.addr == 0 && ipaddr->addr != 0) {

		esp_server_ip.addr = ipaddr->addr;

#if XLINK_DEBUG_ON
		//os_printf("******have got resolve server ip******\r\n");
#endif
		if(esp_server_ip.addr == 0)return;

		os_timer_disarm(&dns_resolve_timer);
		g_AllSta.bit.isConnectedServer = 0;
		g_AllSta.bit.isTcpReconnect = 0;
		dns_resolve_done_flag = true;
		xlink_tcp_init(ipaddr,XLINK_SERVER_PORT);
	}
}

static void XLINK_FUNC user_xlink_platform_dns_check_cb(void *arg) {

	struct espconn *pespconn = arg;

#if XLINK_DEBUG_ON
	//xlink_printf("user_xlink_platform_dns_check_cb\n");
#endif
	espconn_gethostbyname(pespconn, XLINK_DOMAIN, &esp_server_ip,xlink_platform_dns_found);
	os_timer_arm(&dns_resolve_timer, 1000, 0);
}

static void XLINK_FUNC xlink_platform_start_dns(struct espconn *pespconn) {

	esp_server_ip.addr = 0;
	espconn_gethostbyname(pespconn, XLINK_DOMAIN, &esp_server_ip,xlink_platform_dns_found);

	os_timer_disarm(&dns_resolve_timer);
	os_timer_setfn(&dns_resolve_timer,(os_timer_func_t *) user_xlink_platform_dns_check_cb, pespconn);
	os_timer_arm(&dns_resolve_timer, 1000, 0);
}



void XLINK_FUNC xlink_tcp_init(ip_addr_t *ipaddr_t,int s_port) {

	if (xlink_tcp_net_client.proto.tcp == NULL) {
		xlink_tcp_net_client.proto.tcp = (esp_tcp*) os_zalloc(sizeof(esp_tcp));
	}

	os_memcpy(xlink_tcp_net_client.proto.tcp->remote_ip, &ipaddr_t->addr, 4);

	if ((xlink_tcp_net_client.proto.tcp->remote_ip[0] == 0) && (xlink_tcp_net_client.proto.tcp->remote_ip[1] == 0) \
			&& (xlink_tcp_net_client.proto.tcp->remote_ip[2] == 0) && (xlink_tcp_net_client.proto.tcp->remote_ip[3] == 0)) {
	   return;
	}

#if XLINK_DEBUG_ON
	os_printf("xlink_tcp_net client ip=%d.%d.%d.%d\n",
				xlink_tcp_net_client.proto.tcp->remote_ip[0], xlink_tcp_net_client.proto.tcp->remote_ip[1],
				xlink_tcp_net_client.proto.tcp->remote_ip[2],xlink_tcp_net_client.proto.tcp->remote_ip[3]);
#endif

	xlink_tcp_net_client.type = ESPCONN_TCP;
	xlink_tcp_net_client.state = ESPCONN_NONE;

	xlink_tcp_net_client.proto.tcp->local_port = TCP_LOCAL_PORT;
	xlink_tcp_net_client.proto.tcp->remote_port = s_port;

	espconn_regist_connectcb(&xlink_tcp_net_client,
			(espconn_connect_callback) xlink_tcp_client_connect_cb);

	espconn_regist_disconcb(&xlink_tcp_net_client,
			(espconn_connect_callback) xlink_tcp_disconnect_cb);

	espconn_regist_reconcb(&xlink_tcp_net_client,
			(espconn_reconnect_callback) xlink_tcp_client_reconnect_cb);

	g_AllSta.bit.isConnectedServer = 0;
#ifdef OPEN_CLIENT_SSL_ENABLE
	espconn_secure_connect(&xlink_tcp_net_client);
#else
	espconn_connect(&xlink_tcp_net_client);
#endif
	XlinkInitData(); //must reinit before tcp connect or when tcp close
}



XLINK_FUNC void xlink_uip_tcp_reinit(void) {

	ip_addr_t raddr;

	if ((xlink_tcp_net_client.proto.tcp->remote_ip[0] == 0) && (xlink_tcp_net_client.proto.tcp->remote_ip[1] == 0) \
			&& (xlink_tcp_net_client.proto.tcp->remote_ip[2] == 0) && (xlink_tcp_net_client.proto.tcp->remote_ip[3] == 0)) {
		if(try_reconnect_num++ >=5 ){
			dns_resolve_done_flag = false;
			try_reconnect_num = 0;
		}
		return;
	}

	if(xlink_tcp_net_client.proto.tcp == NULL){
	   return;
	}
	os_memcpy(&raddr,xlink_tcp_net_client.proto.tcp->remote_ip,4);
	xlink_tcp_init(&raddr,XLINK_SERVER_PORT);
}


//volatile unsigned char sent_connect_event = 0;

void XLINK_FUNC xlink_network_check_ip(void* param) {
	struct ip_info ipConfig;

	wifi_get_ip_info(STATION_IF, &ipConfig);
	if(STATION_GOT_IP == wifi_station_get_connect_status() && ipConfig.ip.addr != 0)
	{
		g_AllSta.bit.isConnectWIFI = 1;

		if(smartlink_config_status() != 0)
			return;

		if(pidkey_w_flag == PIDKEY_WRITE_FLAG)
		{
		  if(dns_resolve_done_flag == false)
		  {
			if(check_is_valid_ip(XLINK_DOMAIN) != 1) //
			{  //is domain mode
				#if XLINK_DEBUG_ON
				os_printf("dns resolve start....\r\n");
				#endif
				user_conn.proto.tcp = &user_tcp;
				user_conn.type = ESPCONN_TCP;
				user_conn.state = ESPCONN_NONE;

				xlink_platform_start_dns(&user_conn);
			}else{
				//is ip mode
				#if XLINK_DEBUG_ON
				os_printf("----is ipaddr mode....\r\n");
				#endif
				if(hf_ip2int(XLINK_DOMAIN, addrptr) != 1){
				}else{
					xlink_tcp_init(addrptr,XLINK_SERVER_PORT);
					dns_resolve_done_flag = true;
				}
			 }
		   }
		}
		xlink_func_process(); //work in station mode
	}
	else
	{
		/* if there are wrong while connecting to some AP, then reset mode */
		if ((wifi_station_get_connect_status() == STATION_WRONG_PASSWORD
				|| wifi_station_get_connect_status() == STATION_NO_AP_FOUND
				|| wifi_station_get_connect_status() == STATION_CONNECT_FAIL)) {

			dns_resolve_done_flag = false;
			g_AllSta.bit.isConnectWIFI = 0; //wifi not connect the router
			wifi_set_opmode(STATION_MODE);
		}
		//xlink_resolve_mcu_cmd();  //when wifi disconnect uart also can work
	}
}

void XLINK_FUNC xlink_network_init(void)
{
	g_AllSta.byte = 0;
	xlink_udp_init();

	xlink_demo_init();
	os_printf("xlink demo init done............\r\n");

	Kfifo_Init(&tcpdata_send, XLINK_TCP_FIFO, TCP_SENDBUFFER_LEN);
	os_printf("tcpdata_send init done............\r\n");

	os_timer_disarm(&net_process_timer);
	os_timer_setfn(&net_process_timer, (os_timer_func_t *)xlink_network_check_ip, NULL);
	os_timer_arm(&net_process_timer, 100, 1);
}


void xlink_disconnect_cloud_process(void)
{
	os_printf("xlink_disconnect_cloud_process\r\n");
	if(g_AllSta.bit.isConnectedServer)
	{
#ifdef OPEN_CLIENT_SSL_ENABLE
		espconn_secure_disconnect(&xlink_tcp_net_client);
#else
		espconn_disconnect(&xlink_tcp_net_client);
#endif
		xsdk_closeTCP(1);
		Kfifo_reset(&tcpdata_send);

		XlinkInitData(); //must reinit before tcp connect or when tcp close

		g_AllSta.bit.isTcpReconnect = 0;
		g_AllSta.bit.isConnectedServer = 0;
	}
}


void XLINK_FUNC xlink_tcp_Heartbeat(uint32_t CurrentTime)
{

	if(g_AllSta.bit.isTcpReconnect == 0 && g_AllSta.bit.isConnectedServer == 0) {
		g_AllSta.bit.isTcpReconnect = 1;
		lastConnectServerTime = CurrentTime;
	}
	else if(g_AllSta.bit.isConnectedServer == 0){
		if((CurrentTime - lastConnectServerTime) > 30){
#if XLINK_DEBUG_ON
			os_printf("tcp init g_AllSta.bit.isTcpReconnect------%s\r\n",__TIME__);
#endif
			g_AllSta.bit.isTcpReconnect = 1;
			lastConnectServerTime = CurrentTime;

#ifdef OPEN_CLIENT_SSL_ENABLE
			espconn_secure_disconnect(&xlink_tcp_net_client);
#else
			espconn_disconnect(&xlink_tcp_net_client);
#endif

			if(tcp_connect_flag == 0){
				Kfifo_reset(&tcpdata_send);
				XlinkInitData(); //must reinit before tcp connect or when tcp close
				xlink_uip_tcp_reinit();
			}else{
				if(lastConnectServerTime >= 25){
					lastConnectServerTime -=25;
				}
				tcp_connect_flag = 0;
			}
		}
	}
}


volatile unsigned int PreTime = 0;

void XLINK_FUNC xlink_func_process(void)
{
	static xsdk_time_t ctime= 0;
	unsigned int temp = 0;

	ctime = system_get_time()/1000000;

	g_AllSta.bit.isSendUartData = 0;

	if(send_data_ack == 0) {
		xlink_resolve_mcu_cmd();
	}

    if(send_data_ack){
		time_send_count++;
		if(time_send_count%8 == 0) //800ms
		{
			time_send_count = 0;
			send_data_ack = 0; //clear to zero
		}
    }
	if(pidkey_w_flag == PIDKEY_WRITE_FLAG){
		xlink_tcp_Heartbeat(ctime);
		XlinkSystemLoop(ctime, 0);
		temp = TICKS_DIFF_T(ctime,PreTime);
		if(temp > 60){
			PreTime = ctime;
			if(g_AllSta.bit.isConnectedServer){
				XlinkGetServerTime();
			}
		}
	}
	XlinkProcessTCPData();
	process_dp_pass_data();
	send_tcpdata_loop();
}


