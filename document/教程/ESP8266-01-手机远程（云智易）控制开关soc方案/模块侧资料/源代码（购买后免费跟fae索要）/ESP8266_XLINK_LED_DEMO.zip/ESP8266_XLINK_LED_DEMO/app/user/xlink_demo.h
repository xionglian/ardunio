#ifndef __XLINK_DEMO_H__
#define __XLINK_DEMO_H__

//#include "../xlinksrc/xlink_system.h"
#include "xlink_system.h"

#define DATAPOINT_DEBUG_ON  		0
#define XLINK_DEBUG_ON      		0
#define FIFO_DEBUG_ON       		0

#define PIDKEY_WRITE_FLAG  			0x55
#define PACKAGE_SENT_ACK_TIMEOUT  	100
#define SET_DP_MAX_LEN  			1024
#define COM_PACKAGE_LEN             1030

extern volatile unsigned char pidkey_w_flag;

//define for process the uart rx data
typedef void(* uart_data_callback_t)(unsigned char *pata,uint32_t date_len);


#ifndef TICKS_DIFF_T
#define TICKS_DIFF_T(cur, prev) ((cur) >= (prev)) ? ((cur)-(prev)) : ((0xFFFFFFFF-(prev))+(cur)+1)
#endif


#define timer_init(timer_var,fun_process,func_para)	    do \
														{ \
															os_timer_disarm(timer_var); \
															os_timer_setfn(timer_var, (os_timer_func_t *)fun_process, func_para); \
														}while(0)


#define timer_start(timer_var,timer_value,cycle_flag)	do \
														{ \
															os_timer_arm(timer_var, timer_value, cycle_flag); \
														}while(0)
#define timer_stop(timer_var)   do \
								{ \
									os_timer_disarm(timer_var); \
								}while(0)

typedef union {
	unsigned char byte;
	struct {
		unsigned char isConnectedServer :1;
		unsigned char isConnectWIFI :1;
		unsigned char isNeedSend :1;
		unsigned char isSendUartData :1;
		unsigned char isNeedSendWifiSta:1;
		unsigned char isNeedSendServerSta:1;
		unsigned char isTcpReconnect:1;
		unsigned char res :1;
	} bit;
} XLINK_LOCAL_STA;


extern XLINK_LOCAL_STA   	g_AllSta;
extern XLINK_USER_CONFIG  	user_config;

extern void  smartlink_config_process(void);
extern int   xlink_demo_init(void);
extern void  xlink_uart_send(unsigned char *Buffer, unsigned short BufferLen);
extern void  uart_data_process_init(void);
extern void  xlink_resolve_mcu_cmd(void);
extern void  process_dp_pass_data(void);

#endif /* XLINK_APPPASSTHROUGH_H_ */
