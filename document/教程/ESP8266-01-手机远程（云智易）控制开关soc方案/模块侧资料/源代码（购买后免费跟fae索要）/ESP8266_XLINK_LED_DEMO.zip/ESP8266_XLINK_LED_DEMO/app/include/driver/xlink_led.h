#ifndef __XLINK_LED_H__
#define __XLINK_LED_H__

#include "c_types.h"

//此GPIO口可根据用户具体使用而更改,如需使用UART功能，则需把此IO更改为其他IO
#define LED_POWER_NAME   PERIPHS_IO_MUX_U0TXD_U//PERIPHS_IO_MUX_GPIO2_U
#define LED_POWER_NUM    1
#define LED_POWER_FUNC   FUNC_GPIO1

#define LED_STATE_NAME   PERIPHS_IO_MUX_GPIO0_U
#define LED_STATE_NUM    0
#define LED_STATE_FUNC   FUNC_GPIO0

//因所使用GPIO口硬件接线的原因，此处0为LED开，1为LED关
#define LED_ON   0
#define LED_OFF  1

void xlink_led_func_init(void);
void xlink_set_led_state(uint32 pin_num,bool status);
#endif /*end of define*/
