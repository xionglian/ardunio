#ifndef __XLINK_SMARTCONFIG_H__
#define __XLINK_SMARTCONFIG_H__

#include "user_interface.h"
#include "smartconfig.h"
#include "osapi.h"


void  smartconfig_done(sc_status status, void *pdata);
void  xlink_smart_stop_cb(void* param);
void  smartlink_config_process(void);
extern uint8_t  smartlink_config_status(void);
//extern BOOL smartlink_success;
#endif /*end of define xlink_wifi_config.h*/




























