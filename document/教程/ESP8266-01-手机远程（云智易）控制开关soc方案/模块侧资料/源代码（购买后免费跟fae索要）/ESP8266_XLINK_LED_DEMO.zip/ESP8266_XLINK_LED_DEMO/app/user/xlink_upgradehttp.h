#ifndef __XLINK_UPGRADEHTTP_H__
#define __XLINK_UPGRADEHTTP_H__

#include "xlink_demo.h"


#define DBG_HTTP_UPGRADE
//#define DEBUG_HTTP 0

//文件总大小
//已经下载的大小
//当前状态 0 正常
typedef void (*xlinkhttpStaCallBack)(const unsigned int fileSize, const unsigned int rate, const unsigned int sta);
typedef void (*xlinkhttpRecvDataCallBack)(const char *data, unsigned int datalen, const unsigned int fileSize,
		const unsigned int offset);
typedef int (*xlinkhttpErrorCallBack)(const unsigned char errSta);


enum ERR_STATE {
    SUCCESS = 0,
    NULL_POINTER,
    OVER_BOUNDARY,
    INVALID_CHAR,
    INVALID_FORM
};

typedef struct {
	unsigned char ipaddr[72];
	unsigned short port;
	char path[128];
} server_push_upgrade_info_t;

typedef struct http_down_file_t{
	char m_url[256];
	unsigned int m_urlLength;
} xlink_down_file_info;

extern int xlinkHttpStartDownFile(xlink_down_file_info *httpParam);
void  httpTcpClentNetInit(unsigned char *ipaddr);
void  httpDnsFound(const char* name,ip_addr_t *ipaddr,void *arg);



#endif /* XLINKHTTP_H_ */
